<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Kelola Akun Terdaftar
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?= base_url('home') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Akun Terdaftar</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <a href="<?= base_url('/akun/add') ?>" class="btn btn-primary">+ Tambah Akun</a>
            <div class="box" style="margin-top: 10px;">
                <div class="box-body">
                    <?= $this->session->flashdata('message'); ?>
                    <table id="dataTable" class="table display responsive nowrap" style="width:100%">
                        <thead class="bg-primary">
                            <tr>
                                <th>#</th>
                                <th>Username</th>
                                <th>Nama</th>
                                <th>Jabatan</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            foreach ($users as $row) : ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= $row['username'] ?></td>
                                    <td><?= $row['nama_lengkap'] ?></td>
                                    <td><?= $row['level'] ?></td>
                                    <td class="text-center">
                                        <a href="<?= base_url('akun/edit/' . $row['username']); ?>" class="btn btn-sm btn-warning edit"><i class="fa fa-edit"></i></a>
                                        <a href="<?= base_url('akun/delete/' . $row['username']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('apakah anda yakin?')"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php
                            if ($users == null) {
                                echo '<tr><td colspan="5" class="text-center">Tidak ada data</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /.content -->