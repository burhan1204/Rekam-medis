-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 02 Nov 2023 pada 16.58
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `klinik-azkia`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` enum('super','dokter') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `nama_lengkap`, `password`, `level`) VALUES
(1, 'admin', 'Administrator', '$2y$10$5t/nSWXjPk/B8QXMSKseO.6LKHJsgd2aj/28axdkrnxgGSq5ZVIu2', 'super'),
(3, 'ahmad', 'admin', '$2y$10$ye6SeveL5OeODf73nH5gQuoU5T2eSVwEIyIXzY0fMI3BTYXZ6ckKW', 'dokter');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekam-medis`
--

CREATE TABLE `rekam-medis` (
  `id` int(11) NOT NULL,
  `kd_rekam` char(6) NOT NULL,
  `tanggal` datetime NOT NULL,
  `alergi` text DEFAULT NULL,
  `fisik` text NOT NULL,
  `diagnosa` text NOT NULL,
  `therapi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `rekam-medis`
--

INSERT INTO `rekam-medis` (`id`, `kd_rekam`, `tanggal`, `alergi`, `fisik`, `diagnosa`, `therapi`) VALUES
(2323232, '01', '2023-10-05 21:26:00', 'asasa', 'fvbbgvbv', '34343', 'kl;;'),
(2323233, '01', '2023-11-17 22:36:00', 'asa', 'asas', 'asas', 'asasa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `kd_rekam` char(6) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `rt` char(2) NOT NULL,
  `rw` char(2) NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`kd_rekam`, `nama`, `tgl_lahir`, `alamat`, `no_hp`, `tempat_lahir`, `rt`, `rw`, `jenis_kelamin`) VALUES
('01', 'asasa', '1999-09-09', 'asasa', '0987567', 'kempo', '11', '11', 'Laki-laki'),
('02', 'asasasa', '1999-12-18', 'asas', '12312121', 'adsaa', '01', '02', 'Laki-laki');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `rekam-medis`
--
ALTER TABLE `rekam-medis`
  ADD UNIQUE KEY `kd_rekam` (`id`),
  ADD KEY `kd_rekam_2` (`kd_rekam`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`kd_rekam`),
  ADD UNIQUE KEY `kd_rekam` (`kd_rekam`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `rekam-medis`
--
ALTER TABLE `rekam-medis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2323234;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `rekam-medis`
--
ALTER TABLE `rekam-medis`
  ADD CONSTRAINT `rekam-medis_ibfk_1` FOREIGN KEY (`kd_rekam`) REFERENCES `users` (`kd_rekam`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
