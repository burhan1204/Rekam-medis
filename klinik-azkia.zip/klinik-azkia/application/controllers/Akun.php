<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Akun extends CI_Controller
{
    public function index()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect('/auth');
        }

        $data = [
            'title'    => 'Kelola Akun Terdaftar',
            'users'     => $this->db->get('admin')->result_array(),
        ];
        // var_dump($kd_buku); die;
        $this->template->load('admin/template', 'admin/akun/index', $data);
    }

    public function add()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $data = [
            'title'    => 'Tambah Akun Terdaftar',
        ];
        $this->template->load('admin/template', 'admin/akun/add', $data);
    }

    public function store()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if (isset($_POST)) {
            //check username if exist
            $username = $this->input->post('username');
            $check = $this->db->get_where('admin', ['username' => $username])->row_array();
            if ($check) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Maaf, username sudah terdaftar!</div>');
                redirect('/akun/add');
            }
            //check password and password_confirm if match
            $password = $this->input->post('password');
            $password_confirm = $this->input->post('password_confirm');

            if ($password != $password_confirm) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Maaf, password tidak sama!</div>');
                redirect('/akun/add');
            }

            $data = [
                'username'     => $this->input->post('username'),
                'nama_lengkap' => $this->input->post('nama_lengkap'),
                'password'     => password_hash($password, PASSWORD_DEFAULT),
                'level'        => $this->input->post('level'),
            ];

            if ($this->db->insert('admin', $data)) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Tambah Data!</div>');
                redirect('/akun');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Maaf, gagal tambah data!</div>');
                redirect('/akun/add');
            }
        }
    }

    public function edit($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $data = [
            'title'    => 'Edit Akun Terdaftar',
            'user'     => $this->db->get_where('admin', ['username' => $id])->row_array(),
        ];
        $this->template->load('admin/template', 'admin/akun/edit', $data);
    }

    public function update($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if (isset($_POST)) {

            //check password and password_confirm if match
            $password = $this->input->post('password');
            $password_confirm = $this->input->post('password_confirm');

            if ($password != $password_confirm && ($password != "" || $password_confirm != "")) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Maaf, password tidak sama!</div>');
                redirect('/akun/add');
            }

            $data = [
                'nama_lengkap' => $this->input->post('nama_lengkap'),
                'password'     => $this->input->post('password'),
                'level'        => $this->input->post('level'),
            ];

            //if password is not empty
            if ($password != "" || $password_confirm != "") {
                $data['password'] = password_hash($password, PASSWORD_DEFAULT);
            }

            if ($this->db->update('admin', $data, ['username' => $id])) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Ubah Data!</div>');
                redirect('/akun');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Maaf, ubah data!</div>');
                redirect('/akun');
            }
        }
    }

    public function delete($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        //cant delete user when login
        if ($id == $this->session->userdata('username')) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Maaf, anda tidak bisa menghapus akun anda sendiri!</div>');
            redirect('/akun');
        }

        if ($this->db->delete('admin', ['username' => $id])) {
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Hapus Data!</div>');
            redirect('/akun');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Maaf, gagal hapus data!</div>');
            redirect('/akun');
        }
    }
}
