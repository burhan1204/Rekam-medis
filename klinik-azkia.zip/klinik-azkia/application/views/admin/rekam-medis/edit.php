<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Edit Rekam Medis
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?= base_url('home') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Rekam Medis</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box" style="margin-top: 10px;">
                <div class="box-body">
                    <?= $this->session->flashdata('message'); ?>
                    <form action="<?= base_url("/rekammedis/update/" . $rekam_medis['id']) ?>" method="POST">

                        <div class="form-group">
                            <label for="kd_rekam">Pasien</label>
                            <select name="kd_rekam" id="kd_rekam" class="form-control select2">
                                <?php foreach ($pasien as $row) : ?>
                                    <option selected="<?= $rekam_medis['kd_rekam'] == $row['kd_rekam'] ?>" value="<?= $row['kd_rekam'] ?>"><?= $row['kd_rekam'] ?> - <?= $row['nama'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="tanggal">Tanggal</label>
                            <input value="<?= $rekam_medis['tanggal'] ?>" required type="datetime-local" class="form-control" id="tanggal" name="tanggal" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="alergi">Riwayat Alergi</label>
                            <textarea name="alergi" id="alergi" required class="form-control" rows="2" placeholder="Masukkan riwayat alergi..."><?= $rekam_medis['alergi'] ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="fisik">Pemeriksaan Fisik</label>
                            <textarea name="fisik" id="fisik" required class="form-control" rows="2" placeholder="Masukkan pemeriksaan fisik..."><?= $rekam_medis['fisik'] ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="diagnosa">Diagnosa</label>
                            <textarea name="diagnosa" id="diagnosa" required class="form-control" rows="2" placeholder="Masukkan diagnosa..."><?= $rekam_medis['diagnosa'] ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="therapi">Therapi</label>
                            <textarea name="therapi" id="therapi" required class="form-control" rows="2" placeholder="Masukkan therapi..."><?= $rekam_medis['therapi'] ?></textarea>
                        </div>
                        <div class="pull-right">
                            <a href="<?= base_url('/rekammedis') ?>" class="btn btn-default" style="margin-right:1rem">Batal</a>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /.content -->