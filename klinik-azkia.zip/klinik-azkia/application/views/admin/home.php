<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
		Dashboard
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li class="active">Dashboard</li>
	</ol>
</section>

<!-- Main content -->
<section class="content">
	<!-- Info boxes -->
	<div class="row">
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-user"></i></span>
				<div class="info-box-content">
					<span class="info-box-text">Jumlah<br>Pengguna</span>
					<span class="info-box-number"><?= $jml_buku ?></span>
					<a href="<?= base_url('buku') ?>">lihat selengkapnya ></a>
				</div>
				<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
		</div>
		<!-- /.col -->
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-red"><i class="fa fa-money"></i></span>

				<div class="info-box-content">
					<span class="info-box-text">Jumlah<br>Denda</span>
					<span class="info-box-number"><?= $denda == null ? 'Rp.0' : 'Rp.' . number_format($denda) ?></span>
					<a href="<?= base_url('transaksi/kembali') ?>">lihat selengkapnya ></a>
				</div>
				<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
		</div>
		<!-- /.col -->

		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-green"><i class="fa fa-user"></i></span>

				<div class="info-box-content">
					<span class="info-box-text">Jumlah<br>Peminjaman</span>
					<span class="info-box-number"><?= $pinjam ?></span>
					<a href="<?= base_url('transaksi/pinjam') ?>">lihat selengkapnya ></a>
				</div>
				<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
		</div>
		<!-- /.col -->
		<div class="col-md-3 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-yellow"><i class="fa fa-user"></i></span>

				<div class="info-box-content">
					<span class="info-box-text">Jumlah<br>Pengembalian</span>
					<span class="info-box-number"><?= $kembali ?></span>
					<a href="<?= base_url('transaksi/kembali') ?>">lihat selengkapnya ></a>
				</div>
				<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
		</div>
		<!-- /.col -->

		<!-- fix for small devices only -->
		<div class="clearfix visible-sm-block"></div>



	</div>

</section>
<!-- /.content -->