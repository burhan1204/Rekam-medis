<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Kelola Rekam Medis
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?= base_url('home') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Kelola Rekam Medis</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <a href="<?= base_url('/rekammedis/add') ?>" class="btn btn-primary">+ Tambah Rekam Medis</a>
            <div class="box" style="margin-top: 10px;">
                <div class="box-body">
                    <?= $this->session->flashdata('message'); ?>
                    <table id="dataTable" class="table display responsive nowrap" style="width:100%">
                        <thead class="bg-primary">
                            <tr>
                                <th>#</th>
                                <th>No Rekam Medis</th>
                                <th>Nama</th>
                                <th>Umur</th>
                                <th>Diagnosa</th>
                                <th>Tanggal/Jam</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            foreach ($users as $row) : ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= $row['kd_rekam'] ?></td>
                                    <td><?= $row['nama'] ?></td>
                                    <td>
                                        <?= date_diff(date_create($row['tgl_lahir']), date_create('today'))->y ?>
                                        Tahun
                                    </td>
                                    <td><?= substr($row['diagnosa'], 0, 50) ?></td>
                                    <td><?= $row['tanggal'] ?></td>
                                    <td class="text-center">
                                        <a href="<?= base_url('rekammedis/edit/' . $row['id']); ?>" class="btn btn-sm btn-warning edit"><i class="fa fa-edit"></i></a>
                                        <a href="<?= base_url('rekammedis/cetak/' . $row['id']); ?>" class="btn btn-sm btn-info"><i class="fa fa-print"></i></a>
                                        <a href="<?= base_url('rekammedis/delete/' . $row['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('apakah anda yakin?')"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php
                            if ($users == null) {
                                echo '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /.content -->