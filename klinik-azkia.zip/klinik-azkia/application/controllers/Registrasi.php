<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Registrasi extends CI_Controller
{
    public function index()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect('/auth');
        }

        $data = [
            'title'    => 'Kelola Registrasi',
            'users'     => $this->db->order_by('kd_rekam', 'desc')->get('users')->result_array(),
        ];
        // var_dump($kd_buku); die;
        $this->template->load('admin/template', 'admin/registrasi/index', $data);
    }

    public function add()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $data = [
            'title'    => 'Tambah Registrasi',
        ];
        $this->template->load('admin/template', 'admin/registrasi/add', $data);
    }

    public function store()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if (isset($_POST)) {
            $data = [
                'kd_rekam'        => $this->input->post('kd_rekam'),
                'nama'          => $this->input->post('nama'),
                'tgl_lahir'     => $this->input->post('tgl_lahir'),
                'alamat'        => $this->input->post('alamat'),
                'no_hp'         => $this->input->post('no_hp'),
                'tempat_lahir'  => $this->input->post('tempat_lahir'),
                'rt'            => $this->input->post('rt'),
                'rw'            => $this->input->post('rw'),
                'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            ];

            if ($this->db->insert('users', $data)) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Tambah Data!</div>');
                redirect('/registrasi');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"Maaf, tambah data!</div>');
                redirect('/registrasi');
            }
        }
    }

    public function edit($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $data = [
            'title'    => 'Edit Registrasi',
            'user'     => $this->db->get_where('users', ['kd_rekam' => $id])->row_array(),
        ];
        $this->template->load('admin/template', 'admin/registrasi/edit', $data);
    }

    public function cetak($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $user = $this->db->get_where('users', ['kd_rekam' => $id])->row_array();

        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'landscape');
        $this->pdf->filename = "PASIEN-REG-" . $user['kd_rekam'] . ".pdf";
        $this->pdf->save_pdf('admin/registrasi/cetak', [
            'user'  => $user
        ]);

        // $data = [
        //     'user'  => $user,
        // ];
        // $this->load->view('admin/registrasi/cetak', $data);
    }

    public function update($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if (isset($_POST)) {
            $data = [
                'nama'          => $this->input->post('nama'),
                'tgl_lahir'     => $this->input->post('tgl_lahir'),
                'alamat'        => $this->input->post('alamat'),
                'no_hp'         => $this->input->post('no_hp'),
                'tempat_lahir'  => $this->input->post('tempat_lahir'),
                'rt'            => $this->input->post('rt'),
                'rw'            => $this->input->post('rw'),
                'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            ];

            if ($this->db->update('users', $data, ['kd_rekam' => $id])) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Ubah Data!</div>');
                redirect('/registrasi');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"Maaf, ubah data!</div>');
                redirect('/registrasi');
            }
        }
    }

    public function delete($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if ($this->db->delete('users', ['kd_rekam' => $id])) {
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Hapus Data!</div>');
            redirect('/registrasi');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"Maaf, gagal hapus data!</div>');
            redirect('/registrasi');
        }
    }
}
