<?php
defined('BASEPATH') or exit('No direct script access allowed');

class RekamMedis extends CI_Controller
{
    public function index()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect('/auth');
        }

        $data = [
            'title'    => 'Kelola Rekam Medis',
            'users'     => $this->db->join('users', 'users.kd_rekam = rekam-medis.kd_rekam')->order_by('id', 'desc')->get('rekam-medis')->result_array(),
        ];
        // var_dump($kd_buku); die;
        $this->template->load('admin/template', 'admin/rekam-medis/index', $data);
    }

    public function add()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $data = [
            'title'    => 'Tambah Rekam Medis',
            'pasien'   => $this->db->get('users')->result_array(),
        ];
        $this->template->load('admin/template', 'admin/rekam-medis/add', $data);
    }

    public function store()
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if (isset($_POST)) {
            $data = [
                'kd_rekam'      => $this->input->post('kd_rekam'),
                'tanggal'       => $this->input->post('tanggal'),
                'alergi'        => $this->input->post('alergi'),
                'fisik'         => $this->input->post('fisik'),
                'diagnosa'      => $this->input->post('diagnosa'),
                'therapi'       => $this->input->post('therapi'),
            ];

            if ($this->db->insert('rekam-medis', $data)) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Tambah Data!</div>');
                redirect('/rekammedis');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"Maaf, tambah data!</div>');
                redirect('/rekammedis');
            }
        }
    }

    public function edit($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $data = [
            'title'    => 'Edit Registrasi',
            'rekam_medis'     => $this->db->get_where('rekam-medis', ['id' => $id])->row_array(),
            'pasien' => $this->db->get('users')->result_array()
        ];
        $this->template->load('admin/template', 'admin/rekam-medis/edit', $data);
    }

    public function cetak($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }
        $user = $this->db->join('users', 'users.kd_rekam = rekam-medis.kd_rekam')->order_by('id', 'desc')->get_where('rekam-medis',  ['id' => $id])->row_array();

        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'landscape');
        $this->pdf->filename = 'REKAM-MEDIS-' . date('Y-m-d H:i:s') . $user['kd_rekam'] . ".pdf";
        $this->pdf->save_pdf('admin/rekam-medis/cetak', ['user' => $user]);
        // $data = [
        //     'user'  => $user,
        // ];
        // // var_dump($data);
        // // die;
        // $this->load->view('admin/rekam-medis/cetak', $data);
    }

    public function update($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if (isset($_POST)) {
            $data = [
                'kd_rekam'        => $this->input->post('kd_rekam'),
                'tanggal'       => $this->input->post('tanggal'),
                'alergi'        => $this->input->post('alergi'),
                'fisik'         => $this->input->post('fisik'),
                'diagnosa'      => $this->input->post('diagnosa'),
                'therapi'       => $this->input->post('therapi'),
            ];

            if ($this->db->update('rekam-medis', $data, ['id' => $id])) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Ubah Data!</div>');
                redirect('/rekammedis');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"Maaf, ubah data!</div>');
                redirect('/rekammedis');
            }
        }
    }

    public function delete($id)
    {
        if (!$this->session->userdata('isLogin')) {
            redirect(base_url());
        }

        if ($this->db->delete('rekam-medis', ['id' => $id])) {
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Hapus Data!</div>');
            redirect('/rekammedis');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"Maaf, gagal hapus data!</div>');
            redirect('/rekammedis');
        }
    }
}
