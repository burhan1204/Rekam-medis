<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Edit Registrasi
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?= base_url('home') ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registrasi</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box" style="margin-top: 10px;">
                <div class="box-body">
                    <?= $this->session->flashdata('message'); ?>
                    <form action="<?= base_url("/registrasi/update/" . $user['kd_rekam']) ?>" method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kd_rekam">Nomor Rekam Medis</label>
                                    <input disabled value="<?= $user['kd_rekam'] ?>" required type="text" class="form-control" id="kd_rekam" name="kd_rekam" placeholder="Masukkan Nomor Registrasi">
                                </div>
                                <div class="form-group">
                                    <label for="nama">Nama Lengkap</label>
                                    <input value="<?= $user['nama'] ?>" required type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama lengkap">
                                </div>
                                <div class="form-group">
                                    <label for="tgl_lahir">Tanggal Lahir</label>
                                    <input value="<?= $user['tgl_lahir'] ?>" required type="date" class="form-control" id="tgl_lahir" name="tgl_lahir" placeholder="">
                                </div>
                                <div class="form-group">
                                    <label for="no_hp">Nomor HP</label>
                                    <input value="<?= $user['no_hp'] ?>" required type="number" class="form-control" id="no_hp" name="no_hp" placeholder="Masukkan Nomor Telephone">
                                </div>
                                <div class="form-group">
                                    <label for="jenis_kelamin">Jenis Kelamin</label>
                                    <select required id="jenis_kelamin" name="jenis_kelamin" class="form-control">
                                        <option <?= $user['jenis_kelamin'] === 'Laki-laki' ? 'selected' : '' ?> value="Laki-laki">Laki-laki</option>
                                        <option <?= $user['jenis_kelamin'] === 'Perempuan' ? 'selected' : '' ?> value="Perempuan">Perempuan</option>
                                    </select>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tempat_lahir">Tempat Lahir</label>
                                    <input value="<?= $user['tempat_lahir'] ?>" required type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" placeholder="Masukkan Nomor Telephone">
                                </div>
                                <div class="form-group">
                                    <label for="alamat">Alamat</label>
                                    <textarea name="alamat" id="alamat" required class="form-control" rows="2" placeholder="Masukkan alamat lengkap ..."><?= $user['alamat'] ?></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="rt">RT</label>
                                            <input value="<?= $user['rt'] ?>" required type="number" class="form-control" id="rt" name="rt" placeholder="Masukkan RT">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="rw">RW</label>
                                            <input value="<?= $user['rw'] ?>" required type="number" class="form-control" id="rw" name="rw" placeholder="Masukkan RW">
                                        </div>
                                    </div>
                                </div>
                                <div class="pull-right">
                                    <a href="<?= base_url('/registrasi') ?>" class="btn btn-default" style="margin-right:1rem">Batal</a>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>