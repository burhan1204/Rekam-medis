<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap">
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box !important;
        }

        @page {
            size: A4;
            margin: 2cm;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            font-size: 10pt;
            margin: 0;
            padding: 1cm;
        }

        hr {
            margin: 0.8cm 0;
            height: 0;
            border: 0;
            border-top: 1mm solid #00a5ce;
        }

        header {
            height: 4cm;
            padding: 0 1cm;
            align-items: center;
            background-color: #B8E6F1;
        }

        header .headerSection {
            display: flex;
            height: 4cm;
            align-items: center;
            justify-content: space-between;
        }

        header .headerSection:first-child {
            padding-top: .5cm;
        }

        header .headerSection:last-child {
            padding-bottom: .5cm;
        }

        header .headerSection div:last-child {
            width: 35%;
            margin-top: 1cm;
        }

        header .headerSection:last-child div:last-child {
            width: auto;
        }

        header .logoAndName {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        header .logoAndName svg {
            width: 1.5cm;
            height: 1.5cm;
            margin-right: .5cm;
        }

        header h1,
        header h2,
        header h3,
        header p {
            margin: 0;
        }

        header h2,
        header h3 {
            text-transform: uppercase;
        }

        header h2 {
            font-size: 120%;
        }

        .formLine {
            display: flex;
            align-items: flex-start;
            /* margin-left: calc(-1 * 15px); */
            /* Use a fixed value for now */
            margin-bottom: .5cm;
        }

        .formLineWrap {
            flex-wrap: wrap;
        }



        label {
            font-weight: bold;
            color: #00a5ce;
        }

        label+input[type="text"],
        label+select {
            margin-top: 2px;
        }

        label.sublabel {
            font-size: 0.85em;
            text-transform: uppercase;
            color: #868f95;
            padding-bottom: 0.25em;
        }

        .w100 {
            width: 100%;
        }

        .w66 {
            width: 66%;
        }

        .w50 {
            width: 50%;
        }

        .w33 {
            width: 33%;
        }

        input[type="text"] {
            width: 100%;
            height: 25px;
            line-height: 20px;
            padding-left: 10px;
        }

        select {
            width: 100%;
            height: 25px;
        }

        input[type="checkbox"],
        input[type="radio"] {
            margin-right: 4px;
        }

        input[type="submit"] {
            background-color: #00a5ce;
            color: white;
            font-weight: bold;
            border: none;
            padding: 5px;
        }

        aside {
            padding: 0 2cm .5cm 2cm;
        }

        aside p {
            margin: 0;
            column-count: 2;
        }

        footer {
            height: 3cm;
            line-height: 3cm;
            padding: 0 2cm;
            font-size: 8pt;
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            background-color: #BFC0C3;
        }

        footer a:first-child {
            font-weight: bold;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }
    </style>
</head>

<body>
    <header>
        <div class="headerSection">
            <div class="logoAndName">
                <h1>Klinik Azkia Medika Berkah</h1>
            </div>
            <div>
                <h2></h2>
                <p>
                    <b>Jabong, Pagaden, Subang Regency, <br /> West Java 41252</b>
                </p>
            </div>
        </div>
    </header>

    <!-- <main style="padding-top:1rem;">
        <div class="formLine">
            <div class="w100">
                <label>Nomor Registrasi</label>
                <input type="text" value="<?= $user['no_reg'] ?>" name="FirstName" />
            </div>
        </div>
        <div class="formLine">
            <div class="w100 ">
                <label>Nama Pasien</label>
                <input value="<?= $user['nama'] ?>" type="text" name="MiddleName" />
            </div>
        </div>
        <div class="formLine">
            <div class="w100 ">
                <label>Tanggal Lahir</label>
                <input type="text" value="<?= $user['tgl_lahir'] ?>" name="LastName" />
            </div>
        </div>
        <div class="formLine">
            <div class="w100 ">
                <label>Jenis Kelamin</label>
                <input type="text" value="<?= $user['jenis_kelamin'] ?>" name="LastName" />
            </div>
        </div>
        <div class="formLine">
            <div class="w100 ">
                <label>Alamat</label>
                <textarea style="width: 100%; padding-left: 10px; padding-top:5px; color:black; font-family: 'Montserrat', sans-serif;" rows="3"><?= $user['alamat'] ?></textarea>
            </div>
        </div>
        <hr />
    </main> -->
    <table style="margin-top:1rem; border: 1px solid black;" border="2">

        <tr>
            <td style="width: 15%;">No Rekam Medis</td>
            <td colspan="3">: <?= $user['kd_rekam'] ?></td>
        </tr>
        <tr>
            <td style="width: 15%;">Nama Pasien</td>
            <td>: <?= $user['nama'] ?></td>
            <td style="width: 15%;">Alamat</td>
            <td>: <?= $user['alamat'] ?></td>
        </tr>
        <tr>
            <td style="width: 15%;">Tempat lahir</td>
            <td>: <?= $user['tempat_lahir'] ?></td>
            <td style="width: 15%;">Ruangan</td>
            <td>: - </td>
        </tr>
        <tr>
            <td style="width: 15%;">Tanggal Lahir</td>
            <td>: <?= $user['tgl_lahir'] ?></td>
            <td style="width: 15%;">Telp</td>
            <td>: <?= $user['no_hp'] ?></td>
        </tr>
    </table>

    <table style="margin-top:1rem; border: 1px solid black;" border="2">
        <tr>
            <th style="text-align: center;">Tanggal</th>
            <th style="text-align: center;">Perjalanan Penyakit</th>
            <th style="text-align: center;">Instruksi Terapi</th>
            <th style="text-align: center;">Tanda Tangan dan Nama Jelas</th>
        </tr>
        <tr>
            <td style="padding: 2rem 1rem;"> <?= $user['tanggal'] ?></td>
            <td style="padding: 2rem 1rem;"> <?= $user['alergi'] ?></td>
            <td style="padding: 2rem 1rem;"> <?= $user['therapi'] ?></td>
            <td style="padding: 2rem 1rem;"></td>
        </tr>
    </table>
</body>

</html>